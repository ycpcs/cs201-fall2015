package edu.ycp.cs201.sort;

import junit.framework.TestCase;

public class SortTest extends TestCase {
	private String[] words;
	
	@Override
	protected void setUp() throws Exception {
		// Source of random words: http://www.fourteenminutes.com/fun/words/
		words = new String[]{
				"natee",
				"quadiuseiskidneyelmhure",
				"frive",
				"waltaging",
				"hio",
				"avation",
				"nigena",
				"vigistomer",
				"burrility",
				"lighway",
				"led",
				"mimilkante",
				"comfortiversta",
				"untoe",
				"canastach",
				"whiste",
				"ges",
				"rendumpounicialiker",
				"kathawkwaratesterfulneed",
				"peckstume",
		};
	}
	
	private static<E extends Comparable<E>> boolean isSorted(E[] arr) {
		for (int i = 1; i < arr.length; i++) {
			if (arr[i-1].compareTo(arr[i]) > 0) {
				return false;
			}
		}
		return true;
	}
	
	public void testInsertionSort() throws Exception {
		Sort.insertionSort(words);
		/*
		for (String s : words) {
			System.out.println(s);
		}
		*/
		assertTrue(isSorted(words));
	}
	
	public void testShellSort() throws Exception {
		Sort.shellSort(words);
		/*
		for (String s : words) {
			System.out.println(s);
		}
		*/
		assertTrue(isSorted(words));
	}
}
