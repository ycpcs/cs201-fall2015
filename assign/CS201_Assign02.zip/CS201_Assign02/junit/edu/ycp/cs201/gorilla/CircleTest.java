package edu.ycp.cs201.gorilla;

import static org.junit.Assert.*;
import edu.ycp.cs201.gorilla.Circle;
import edu.ycp.cs201.gorilla.Point;

import org.junit.Before;
import org.junit.Test;

public class CircleTest {
	// When comparing floating point values for equality, allow
	// a small "fudge factor" to account for the fact that floating
	// point arithmetic is not exact
	private static final double DELTA = 0.00001;
	
	// TODO: fields for text fixture objects
	private Circle atOrigin;
	
	@Before
	public void setUp() {
		// TODO: create test fixture objects
		atOrigin = new Circle(new Point(0, 0), 10.0);
	}
	
	// TODO: test methods
	
	@Test
	public void testGetRadius() throws Exception {
		assertEquals(10.0, atOrigin.getRadius(), DELTA);
	} 
}
