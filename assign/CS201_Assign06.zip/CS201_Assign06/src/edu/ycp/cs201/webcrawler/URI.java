package edu.ycp.cs201.webcrawler;

/**
 * Static methods for working with URIs.
 * Note that in this project, we omit the
 * protocol ("http:", "file:", "mailto:", etc.)
 * part of URIs.  So, our URIs are
 * essentially just file names.
 */
public class URI {
	/**
	 * Translate a URI into canonical form.
	 * Canonical form means that all occurrences of
	 * "." and ".." in the URI are eliminated.
	 * Examples:
	 * <p>"foo/bar.html" is already in canonical form</p>
	 * <p>"foo/./bar.html" becomes "foo/bar.html",
	 *    because the "." component means "the current directory"</p>
	 * <p>"foo/baz/../bar.html" becomes "foo/bar.html",
	 *    because the ".." component means "the parent directory"</p>
	 * 
	 * See the unit tests defined in the URITest class.
	 * 
	 * @param uri a URI
	 * @return an equivalent URI in canonical form
	 */
	public static String makeCanonical(String uri) {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Get the directory part of a URI.
	 * 
	 * Examples:
	 * <p>the directory part of "foo/bar.html" is "foo/"</p>
	 * <p>the directory part of "/foo/bar.html" is "/foo/"</p>
	 * <p>the directory part of "index.html" is "" (the empty string)</p>
	 * 
	 * Note that with the exception of the empty string,
	 * all directory URIs end with a "/" character.
	 * 
	 * @param uri a URI
	 * @return the directory part of the URI
	 */
	public static String getDirectory(String uri) {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Return true if the given URI is relative, 
	 * or false if it is absolute.
	 * A URI is relative if it does not start with a "/" character.
	 * 
	 * Examples:
	 * <p> "foo/bar.html" is relative</p>
	 * <p> "index.html" is relative</p>
	 * <p> "/foo/bar.html" is not relative</p>
	 * 
	 * @param uri a URI
	 * @return true if the URI is relative, false otherwise
	 */
	public static boolean isRelative(String uri) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Return the full canonical form of a URI referenced
	 * from another web page. 
	 * 
	 * <p>If the referenced URI is absolute, then
	 *    the method should just return the canonical
	 *    form of the URI.</p>
	 * <p>If the referenced URI is not absolute, then
	 *    the method should return the canonical form
	 *    of the concatenation of the base URI's
	 *    directory part with the referenced URI.</p>
	 * 
	 * @param baseUri the URI of a base web page
	 * @param refUri  a URI referenced from within the base web page
	 * @return the full canonical form of a URI referenced
	 *         from the base web page
	 */
	public static String getReferencedURI(String baseUri, String refUri) {
		throw new UnsupportedOperationException();
	}
}
