package edu.ycp.cs201.exam1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class HistogramGUI extends JPanel {
	private Random rng;
	private Histogram model;
	
	public HistogramGUI() {
		setPreferredSize(new Dimension(640, 480));
		setBackground(Color.DARK_GRAY);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClicked(e);
			}
		});
		
		rng = new Random(123L);
		fillHistogram();
	}

	private void fillHistogram() {
		System.out.print("Calculating...");
		System.out.flush();
		model = new Histogram(64);
		for (int i = 0; i < 10000; i++) {
			int bucket = roll(4,16);
			model.increment(bucket);
		}
		System.out.println("done");
	}

	private int roll(int ndice, int nsides) {
		int bucket = 0;
		for (int j = 0; j < ndice; j++) {
			bucket += rng.nextInt(nsides);
		}
		return bucket;
	}
	
	protected void handleMouseClicked(MouseEvent e) {
		fillHistogram();
		repaint();
	}
	
	private static final Color LIGHT_CYAN = new Color(165, 204, 209);
	private static final Color GRAYISH = new Color(148, 155, 160);
	private static final Font F = new Font("Dialog", Font.BOLD, 48);

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		for (int i = 0; i < 64; i++) {
			int height = model.get(i);
			//System.out.printf("Height is %d\n", height);
			g.setColor(LIGHT_CYAN);
			g.fillRect(i*10,480-height,10,height);
		}
		
		g.setColor(GRAYISH);
		g.setFont(F);
		g.drawString("Click to regenerate", 50, 240);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				HistogramGUI view = new HistogramGUI();
				JFrame frame = new JFrame("Histogram");
				frame.setContentPane(view);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}
