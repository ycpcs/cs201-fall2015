package edu.ycp.cs201.guidemo;

public class CountController {
	public void increaseCount(CountModel model) {
		model.increase();
	}
	
	public void decreaseCount(CountModel model) {
		model.decrease();
	}
}
