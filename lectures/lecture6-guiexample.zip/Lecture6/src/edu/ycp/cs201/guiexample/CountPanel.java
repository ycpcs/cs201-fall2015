package edu.ycp.cs201.guiexample;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class CountPanel extends JPanel {
        // constants defining the preferred width and height of the panel
        private static final int WIDTH = 400;
        private static final int HEIGHT = 300;

        // this font will be used to display the count
        private static final Font font = new Font("Dialog", Font.BOLD, 48);

        // as the count increases, the rectangle will cycle through these colors
        private static final Color[] colors = { Color.RED, Color.GREEN, Color.BLUE };

        // field storing the current count
        private int count;

        // constructor
        public CountPanel() {
                count = 0;

                setBackground(Color.GRAY);

                setPreferredSize(new Dimension(WIDTH, HEIGHT));

                // install event handlers
                addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
                                handleMouseClick(e);
                        }
                });
        }

        private void handleMouseClick(MouseEvent e) {
                // change the "state" of the program
                count++;

                // now that the state is changed,
                // redraw the panel to reflect the state change
                repaint();
        }

        @Override
        public void paint(Graphics g) {
                super.paint(g); // call the superclass's paint() method to paint the background

                // draw the rectangle
                g.setColor(colors[count % colors.length]);
                g.fillRect(20, 20, WIDTH - 40, HEIGHT - 40);

                // draw the count
                g.setFont(font);
                g.setColor(Color.WHITE);
                g.drawString("" + count, 50, 150);
        }
}
