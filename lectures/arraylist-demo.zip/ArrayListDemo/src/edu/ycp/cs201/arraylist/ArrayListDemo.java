package edu.ycp.cs201.arraylist;

import java.util.ArrayList;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList<String>();
		
		a.add("Alice");
		a.add("Bob");
		a.add("Carl");
		
//		for (int i = 0; i < a.size(); i++) {
//			String elt = a.get(i);
//			System.out.println(elt);
//		}

		System.out.println("Before");
		for (String elt : a) {
			System.out.println(elt);
		}

		// adding a collection of values
		ArrayList<String> more = new ArrayList<String>();
		more.add("XXX");
		more.add("YYY");
		a.addAll(more);

		System.out.println("\nAfter");
		for (String elt : a) {
			System.out.println(elt);
		}

		// removing a collection of values
		ArrayList<String> getRidOf = new ArrayList<String>();
		getRidOf.add("Bob");
		getRidOf.add("YYY");
		getRidOf.add("Not really there");
		
		a.removeAll(getRidOf);
		
		System.out.println("\nAfter remove");
		for (String elt : a) {
			System.out.println(elt);
		}

	}
}
