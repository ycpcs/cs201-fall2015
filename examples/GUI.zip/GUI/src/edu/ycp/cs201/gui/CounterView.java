package edu.ycp.cs201.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class CounterView extends JPanel {
	private Counter model;
	private CounterController controller;
	
	public CounterView() {
		setBackground(Color.DARK_GRAY);
		setPreferredSize(new Dimension(200, 200));
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClicked(e);
			}
		});
	}
	
	private void handleMouseClicked(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			// left button, increase count
			controller.increment(model);
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			// right button, decrease count
			controller.decrement(model);
		}
		
		repaint();
	}
	
	public void setModel(Counter model) {
		this.model = model;
	}
	
	public void setController(CounterController controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// Draw background
		super.paintComponent(g);
		
		g.setColor(new Color(254, 254, 254));
		Font f = new Font(Font.DIALOG, Font.BOLD, 40);
		g.setFont(f);
		g.drawString("" + model.getCount(), 10, 100);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// Create model and controller
				Counter model = new Counter();
				CounterController controller = new CounterController();
				
				// Create view
				CounterView view = new CounterView();
				view.setModel(model);
				view.setController(controller);
				
				// Create a frame
				JFrame frame = new JFrame();
				frame.setContentPane(view);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				frame.setVisible(true);
			}
		});
	}
}
