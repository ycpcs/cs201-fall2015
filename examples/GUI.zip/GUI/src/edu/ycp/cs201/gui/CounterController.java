package edu.ycp.cs201.gui;

public class CounterController {
	public void increment(Counter model) {
		int count = model.getCount();
		count = count + 1;
		model.setCount(count);
	}

	public void decrement(Counter model) {
		int count = model.getCount();
		count = count - 1;
		model.setCount(count);
	}
}
