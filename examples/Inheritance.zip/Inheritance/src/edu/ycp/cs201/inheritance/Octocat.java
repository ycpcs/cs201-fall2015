package edu.ycp.cs201.inheritance;

public class Octocat extends Animal {
	public Octocat() {
		super(8);
	}
	
	@Override
	public void makeSound() {
		System.out.println("Meow");
	}
}
