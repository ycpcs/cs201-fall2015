package edu.ycp.cs201.inheritance;

public class Cat extends Animal {
	public Cat() {
		super(4);
	}
	
	@Override
	public void makeSound() {
		System.out.println("Meow");
	}

}
