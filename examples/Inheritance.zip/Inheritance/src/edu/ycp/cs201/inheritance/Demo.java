package edu.ycp.cs201.inheritance;

public class Demo {
	public static void main(String[] args) {
		Animal cat = new Octocat();
		cat.makeSound();
		System.out.println("Number of legs: " + cat.getNumLegs());
	}
}
