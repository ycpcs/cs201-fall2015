package edu.ycp.cs201.inheritance;

public abstract class Animal {
	private int numLegs;
	
	public Animal(String s) {
		numLegs = Integer.parseInt(s);
	}
	
	public Animal(int numLegs) {
		this.numLegs = numLegs;
	}
	
	public abstract void makeSound();
	
	public int getNumLegs() {
		return numLegs;
	}
}
