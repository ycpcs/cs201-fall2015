package edu.ycp.cs201.fileio;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("output.txt");
		
		fw.write("Hey, this is some text that we are writing\n");
		fw.close();
		
		System.out.println("File written successfully?");
	}
}
