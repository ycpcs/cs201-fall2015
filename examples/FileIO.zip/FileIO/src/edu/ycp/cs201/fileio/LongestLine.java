package edu.ycp.cs201.fileio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LongestLine {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Open what file? ");
		String fileName = keyboard.nextLine();
		
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			int longest = 0;
			
			try {
				boolean done = false;
				while (!done) {
					String line = br.readLine();
					if (line == null) {
						done = true;
					} else {
						if (line.length() > longest) {
							longest = line.length();
						}
					}
				}
			} finally {
				br.close();
			}
			
			System.out.println("Longest line has " + longest + " characters");
		} catch (IOException e) {
			System.out.println("Couldn't read from " + fileName + ": " + e.getMessage());
		}
	}
}
