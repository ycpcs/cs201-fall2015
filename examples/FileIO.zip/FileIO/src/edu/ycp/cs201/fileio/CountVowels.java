package edu.ycp.cs201.fileio;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CountVowels {
	public static void main(String[] args) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Open what file? ");
		String fileName = keyboard.nextLine();
		
		FileReader fileReader = new FileReader(fileName);
		
		int count = 0;
		boolean done = false;
		while (!done) {
			int ch = fileReader.read();
			
			if (ch < 0) {
				done = true;
			} else {
				ch = Character.toLowerCase(ch);
				
				if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
					count++;
				}
			}
		}
		
		fileReader.close();
		
		System.out.println("There were " + count + " vowel(s)");
		
	}
}
