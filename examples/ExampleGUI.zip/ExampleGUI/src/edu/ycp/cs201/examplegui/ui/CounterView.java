package edu.ycp.cs201.examplegui.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import edu.ycp.cs201.examplegui.controller.CounterController;
import edu.ycp.cs201.examplegui.model.Counter;

public class CounterView extends JPanel {
	private Counter model;
	private CounterController controller;

	public CounterView() {
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.DARK_GRAY);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick();
			}
		});
	}
	
	private void handleMouseClick() {
		controller.incrementCounter(model);
		repaint(); // schedules a paint event
	}

	public void setModel(Counter model) {
		this.model = model;
	}

	public void setController(CounterController controller) {
		this.controller = controller;
	}

	@Override
	protected void paintComponent(Graphics g) {
		// Draw background
		super.paintComponent(g);

		g.setColor(Color.GREEN);
		g.fillRect(20, 20, 160, 160);
		
		Font font = new Font("Dialog", Font.BOLD, 44);
		g.setColor(Color.WHITE);
		g.setFont(font);
		g.drawString(String.valueOf(model.getCount()), 60, 60);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Counter model = new Counter();
				CounterController controller = new CounterController();

				CounterView view = new CounterView();
				view.setModel(model);
				view.setController(controller);

				JFrame frame = new JFrame("Counter example");
				frame.setContentPane(view);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}
