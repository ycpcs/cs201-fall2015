package edu.ycp.cs201.examplegui.controller;

import edu.ycp.cs201.examplegui.model.Counter;

public class CounterController {
	public void incrementCounter(Counter counter) {
		counter.increment();
	}
}
