package edu.ycp.cs201.examplegui.model;

public class Counter {
	private int value;
	
	public Counter() {
		value = 0;
	}
	
	public void increment() {
		value++;
	}
	
	public int getCount() {
		return value;
	}
}
