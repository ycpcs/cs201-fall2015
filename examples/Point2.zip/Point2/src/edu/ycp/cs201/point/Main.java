package edu.ycp.cs201.point;

public class Main {
	public static void main(String[] args) {
		Point p = new Point();
		
		p.setX(42.0);
		p.setY(3.4);
		
		System.out.println("p.x is " + p.getX());
		System.out.println("p.y is " + p.getY());

		double dist = p.distFromOrigin();
		System.out.println("dist=" + dist);
	}
}
