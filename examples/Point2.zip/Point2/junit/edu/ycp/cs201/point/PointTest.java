package edu.ycp.cs201.point;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.000001;
	
	// test objects ("test fixture")
	private Point p1;
	private Point p2;
	private Point p3;
	
	// setup method
	@Before
	public void setUp() {
		p1 = new Point();
		p1.setX(3.3);
		p1.setY(4.4);
		
		p2 = new Point(5.5, 6.6);
		
		p3 = p2;
		p3.setX(0.0);
	}
	
	// test methods
	@Test
	public void testGetX() {
		assertEquals(3.3, p1.getX(), DELTA);
		assertEquals(5.5, p2.getX(), DELTA);
		assertEquals(0.0, p3.getX(), DELTA);
	}
	
	@Test
	public void testSetX() {
		p1.setX(10.11);
		assertEquals(10.11, p1.getX(), DELTA);
	}
}
