package edu.ycp.cs201.exceptions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Demo {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		boolean done = false;
		while (!done) {
			System.out.print("Enter filename: ");
			String fileName = keyboard.nextLine();
			try {
				int numLines = countLinesInFile(fileName);
				System.out.println("There are " + numLines + " lines");
				done = true;
			} catch (IOException e) {
				System.out.println("Oops: " + e.getMessage());
				System.out.println("Please re-enter the filename");
			}
		}
	}
	
	public static int countLinesInFile(String fileName) throws IOException {
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		try {
			int count = 0;
			boolean done = false;
			while (!done) {
				String line = br.readLine();
				if (line == null) {
					done = true;
				} else {
					count++;
				}
			}
			return count;
		} finally {
			br.close();
		}
	}
}
