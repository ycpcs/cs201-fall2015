package edu.ycp.cs201.point;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.000001;
	
	// test objects ("test fixture")
	private Point p1;
	private Point p2;
	
	// setup method
	@Before
	public void setUp() {
		p1 = new Point();
		p1.setX(3.3);
		p1.setY(4.4);
		
		p2 = new Point();
		p2.setX(5.5);
		p2.setY(6.6);
	}
	
	// test methods
	@Test
	public void testGetX() {
		assertEquals(3.3, p1.getX(), DELTA);
		assertEquals(5.5, p2.getX(), DELTA);
	}
	
	@Test
	public void testSetX() {
		p1.setX(10.11);
		assertEquals(10.11, p1.getX(), DELTA);
	}
}
