package edu.ycp.cs201.point;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PointTest {
	private static final double DELTA = 0.000001;
	
	// test fixture objects
	private Point p1;
	private Point p2;
	
	// setup method
	@Before
	public void setup() {
		p1 = new Point(0.0, 0.0);
		p2 = new Point(3.0, 4.0);
	}
	
	// test methods
	@Test
	public void testGetX() {
		assertEquals(0.0, p1.getX(), DELTA);
		assertEquals(3.0, p2.getX(), DELTA);
	}
	
	@Test
	public void testDistance() {
		assertEquals(5.0, p1.distance(p2), DELTA);
		assertEquals(5.0, p2.distance(p1), DELTA);
	}
}
