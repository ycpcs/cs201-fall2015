package edu.ycp.cs201.point;

public class Point {
	private double x;
	private double y;
	
	public void setX(double xVal) {
		x = xVal;
	}
	
	public double getX() {
		return x;
	}
	
	public void setY(double yVal) {
		y = yVal;
	}
	
	public double getY() {
		return y;
	}
	
	public double distFromOrigin() {
		return Math.sqrt(x*x + y*y);
	}
}
