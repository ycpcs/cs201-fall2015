package edu.ycp.cs201.point;

public class Point {
	private double x;
	private double y;
	
	public Point(double xVal, double yVal) {
		x = xVal;
		y = yVal;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public double distance(Point other) {
		double xdiff = x - other.x;
		double ydiff = y - other.y;
		return Math.sqrt(xdiff*xdiff + ydiff*ydiff);
	}
}
