package edu.ycp.cs201.inheritance;

public class Boat extends Vehicle {
	public Boat(double maxSpeed) {
		super(maxSpeed);
	}

	@Override
	public boolean startTrip(Terrain t) {
		return t == Terrain.MARINA;
	}

	@Override
	public boolean endTrip(Terrain t) {
		return t == Terrain.MARINA;
	}

	@Override
	public boolean move(Terrain t) {
		return t == Terrain.WATER || t== Terrain.MARINA;
	}

	@Override
	public double getSpeed(Terrain t) {
		if (t == Terrain.WATER) {
			return getMaxSpeed();
		} else if (t == Terrain.MARINA) {
			return 0.25 * getMaxSpeed();
		} else {
			throw new IllegalArgumentException("Boat can't move on " + t);
		}
	}

}
