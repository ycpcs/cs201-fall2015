package edu.ycp.cs201.inheritance;

public class Car extends Vehicle {
	public Car(double maxSpeed) {
		super(maxSpeed);
	}

	@Override
	public boolean endTrip(Terrain t) {
		if ( t == Terrain.AIRPORT || t == Terrain.MARINA ) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean move(Terrain t) {
		if ( t == Terrain.AIRPORT || t == Terrain.MARINA || t == Terrain.ROAD ) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean startTrip(Terrain t) {
		if ( t == Terrain.AIRPORT || t == Terrain.MARINA ) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public double getSpeed(Terrain t) {
		if (t == Terrain.ROAD) {
			return getMaxSpeed();
		} else if (t == Terrain.MARINA || t == Terrain.AIRPORT) {
			return 0.25 * getMaxSpeed();
		} else {
			throw new IllegalArgumentException("A car can't drive on " + t);
		}
	}
}
