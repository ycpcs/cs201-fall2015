package edu.ycp.cs201.objectequality;

public class Main {
	public static void main(String[] args) {
		String s1, s2;
		char[] a = { 'F', 'o', 'o', 'b', 'a', 'r' };
		s1 = "Foobar";
		s2 = "";
		for (int i = 0; i < a.length; i++) {
		  s2 = s2 + a[i];
		}
		System.out.println(s1.equals(s2)); // prints "true"
		System.out.println(s1 == s2);      // prints "false"
	}
}
