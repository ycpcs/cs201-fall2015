package edu.ycp.cs201.playsound;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * Example of playing a sound loaded from an embedded sound resource.
 * This should work with an official Oracle JDK.  It will probably
 * <em>not</em> work with OpenJDK, at least on Linux.
 * 
 * @author David Hovemeyer
 */
public class PlaySound extends JPanel {
	private static final long serialVersionUID = 1L;

	private static final String CLIP_RESOURCE =
			"edu/ycp/cs201/playsound/res/torvalds-says-linux.wav";
	
	private Clip clip;
	
	public PlaySound() {
		setBackground(Color.GRAY);
		setPreferredSize(new Dimension(400, 200));
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick();
			}
		});
		
		try {
			URL resourceUrl = getClass().getClassLoader().getResource(CLIP_RESOURCE);
			if (resourceUrl == null) {
				throw new IllegalStateException("No such resource? " + CLIP_RESOURCE);
			}
			// See:
			// http://stackoverflow.com/questions/21128797/audioinputstream-is-not-working
			AudioInputStream ais = AudioSystem.getAudioInputStream(resourceUrl);
			clip = AudioSystem.getClip();
			clip.open(ais);
		} catch (Exception e) {
			System.err.println("Could not open audio file!");
			e.printStackTrace();
		}
	}
	
	protected void handleMouseClick() {
		System.out.printf("Clip %s running\n", clip.isRunning() ? "is" : "is not");
		if (!clip.isRunning()) {
			clip.setFramePosition(0);
			clip.loop(0);
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Font f = new Font("Dialog", Font.BOLD, 24);
		g.setFont(f);
		g.setColor(Color.WHITE);
		g.drawString("Click to hear sound", 40, 40);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new JFrame();
				frame.add(new PlaySound());
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}
