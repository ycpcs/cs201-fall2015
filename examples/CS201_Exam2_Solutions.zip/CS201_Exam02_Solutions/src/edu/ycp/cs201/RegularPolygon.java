package edu.ycp.cs201;

// CS201 Exam 2, Problem 9 (10 points):
// Create the concrete class RegularPolygon from Shape.  RegularPolygon should also implement
// the Comparable interface, comparing the areas of the two objects.  It has a constructor
// that accepts values for type, origin, sides, and length.  The constructor calls calcPerimeter
// and calcArea to initialize the perimeter and area fields.

// Implement the appropriate accessor methods, restricting access so that only the constructor
// can set the side, length, perimeter, and area fields.  Remember to declare and implement 
//everything necessary to make RegularPolygon a concrete class, except that you can insert 
// <CODE>" in the bodies of any required methods that are not accessor methods or part of the 
// Comparable interface.

// 2 points for correct class definition
public class RegularPolygon extends Shape implements Comparable<Shape> {

	// 1 point for correct fields
	private int sides;
	private double length;
	
	// constructor - call super first to set type and origin
	// then set sides and length
	// then set perimeter and area by calling calc functions
	// 2 points for correct constructor
	public RegularPolygon(String type, Point origin, int sides, double length) {
		super(type, origin);
		this.sides = sides;
		this.length = length;
		setPerimeter(calcPerimeter());
		setArea(calcArea());
	}
	
	// accessor methods for private fields - 1 point for getters (there are no setters)
	// don't implement setter methods, since that is done exclusively by the constructor
	public int getSides() {
		return sides;
	}

	public double getLength() {
		return length;
	}

	// implementing abstract method for Shape class
	// calcPerimeter has direct access to sides and length
	// 1 point for declaring this method
	protected double calcPerimeter() {
		// <CODE>
		// didn't need to include this, but here's the real calculation
		return sides * length;
	}

	// implementing abstract method for Shape class
	// calcArea has direct access to sides and length
	// 1 point for declaring this method	
	protected double calcArea() {
		// <CODE>
		// didn't need to include this, but here's the real calculation
		return (length * length * sides) / (4 * Math.tan(Math.PI/sides));
	}

	// comparing areas - restricted to accepting any class derived from Shape
	//                   all of which will have area defined
	// if we would return the difference of two doubles cast to integers
	// the cast could result in truncation that leads to false equality
	// 2 points for declaring and implementing method
	public int compareTo(Shape s) {
		if (getArea() > s.getArea()) {
			return 1;
		}
		else if (getArea() < s.getArea()) {
			return -1;
		}
		else {
			return 0;
		}
	}	

}
