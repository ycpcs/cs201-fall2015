package edu.ycp.cs201;

// CS201 Exam 2, Problem 8 (10 points):
// Construct the class Shape that has abstract methods for calcPerimeter and calcArea,
// which have no parameters, and return floating point numbers.  Shape also has fields
// named type, origin, perimeter, and area.  type is a String, origin is a Point, and 
// perimeter and area are floating point numbers.

// Make sure to define all of the appropriate accessor functions for the fields in Shape. 
// Allow only the constructor to set type, and for extra credit, only allow sub-classes 
// of Shape to calculate or change perimeter and area.

// 1 point for correct class definition
public abstract class Shape {

	// 2 points for correct field definitions
	private String type;
	private Point origin;
	private double perimeter;
	private double area;

	// Constructor
	// this is the only way that type gets set
	// other parameters could be included here, as well
	// could also set perimeter and area to 0, but they default to 0,
	// and the sub-class will redefine them with concrete values, based
	// on sides and length
	// 1 point for correct constructor
	public Shape(String type, Point origin) {
		this.type = type;	
		this.origin = origin;
	}

	// accessor methods
	// 2 points for all getters
	// 2 points for all setters
	// exclude setType, as it is immutable once it is set in the constructor
	public Point getOrigin() {
		return origin;
	}

	// origin can be set outside of class, so that the shape can be moved
	public void setOrigin(Point origin) {
		this.origin = origin;
	}

	public String getType() {
		return type;
	}

	public double getPerimeter() {
		return perimeter;
	}

	// setPerimeter is protected so that only sub-classes can set it when
	// the shape is concretely defined in a sub-class
	// also accepted public
	protected void setPerimeter(double perimeter) {
		this.perimeter = perimeter;
	}

	public double getArea() {
		return area;
	}
	
	// setArea is protected so that only sub-classes can set it when
	// the shape is concretely defined
	// also accepted public
	protected void setArea(double area) {
		this.area = area;
	}

	// abstract methods that will be used in sub-classes to calculate
	// perimeter and area after the shape is concretely defined in a sub-class
	// 1 point each for declaring abstract methods
	// 1 point each extra credit for declaring as protected, rather than public
	protected abstract double calcPerimeter();

	protected abstract double calcArea();
}
