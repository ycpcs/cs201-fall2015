package edu.ycp.cs201.mvc;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class CounterView extends JPanel {
	private Counter model;
	private CounterController controller;
	
	public CounterView() {
		setPreferredSize(new Dimension(200, 200));
		setBackground(Color.DARK_GRAY);
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
	}
	
	protected void handleMouseClick(MouseEvent e) {
		int button = e.getButton();
		if (button == MouseEvent.BUTTON1) {
			// left click
			controller.increment();
		} else if (button == MouseEvent.BUTTON3) {
			// right click
			controller.decrement();
		}
		
		repaint();
	}

	public void setModel(Counter model) {
		this.model = model;
	}
	
	public void setController(CounterController controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g); // paint background
		
		Font f = new Font("Dialog", Font.BOLD, 64);
		g.setColor(Color.WHITE);
		g.setFont(f);
		g.drawString("" + model.getCount(), 20, 80);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new JFrame("Counter app");
				
				Counter model = new Counter();
				CounterView view = new CounterView();
				view.setModel(model);
				
				CounterController controller = new CounterController();
				controller.setModel(model);
				
				view.setController(controller);
				
				frame.setContentPane(view);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				frame.setVisible(true);
			}
		});
	}
}
