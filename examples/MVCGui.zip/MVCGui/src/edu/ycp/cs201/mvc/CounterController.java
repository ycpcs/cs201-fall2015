package edu.ycp.cs201.mvc;

public class CounterController {
	private Counter model;
	
	public CounterController() {
		
	}
	
	public void setModel(Counter model) {
		this.model = model;
	}
	
	public void increment() {
		int cur = model.getCount();
		cur = cur + 1;
		model.setCount(cur);
	}
	
	public void decrement() {
		int cur = model.getCount();
		if (cur > 0) {
			cur = cur - 1;
			model.setCount(cur);
		}
	}
}
