package edu.ycp.cs201.textio;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("output.txt");
		
		fw.write("This is my output file.  It is great.\n");
		
		fw.close();
		
		System.out.println("Output was written successfully?");
	}
}
