package edu.ycp.cs201.textio;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadCharactersFromFile {
	public static void main(String[] args) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter a filename: ");
		String fileName = keyboard.nextLine();
		
		FileReader fr = new FileReader(fileName); 
		
		int count = 0;
		
		while (true) {
			int c = fr.read();
			if (c < 0) {
				break;
			}
			if (c == 'a' || c == 'A') {
				count++;
			}
		}
		
		System.out.printf("There were %d a character(s)\n", count);
		
		fr.close();
	}
}
