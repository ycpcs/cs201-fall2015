package edu.ycp.cs201.genericmethods;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

public class EmployeeTest {
	private Employee aliceJones;
	private Employee bobSmith;
	private Employee johnSmith;
	private Employee carlJohnson;
	private Employee johnSmith2;
	
	private Employee[] arr;
	
	@Before
	public void setUp() {
		aliceJones = new Employee("Jones", "Alice", 29292);
		bobSmith = new Employee("Smith", "Bob", 295);
		johnSmith = new Employee("Smith", "John", 20985);
		carlJohnson = new Employee("Johnson", "Carl", 2098);
		johnSmith2 = new Employee("Smith", "John", 98633);
		
		arr = new Employee[]{aliceJones, bobSmith, johnSmith, carlJohnson, johnSmith2};
	}
	
	@Test
	public void testCompareTo() {
		assertTrue(aliceJones.compareTo(bobSmith) < 0);
		assertTrue(bobSmith.compareTo(aliceJones) > 0);
		assertTrue(aliceJones.compareTo(aliceJones) == 0);
		assertTrue(johnSmith.compareTo(johnSmith2) < 0);
	}
	
	@Test
	public void testSort() {
		Arrays.sort(arr);
		assertEquals(carlJohnson, arr[0]);
		assertEquals(aliceJones, arr[1]);
		assertEquals(bobSmith, arr[2]);
		assertEquals(johnSmith, arr[3]);
		assertEquals(johnSmith2, arr[4]);
	}
	
	@Test
	public void testBubbleSort() {
		BubbleSort.bubbleSort(arr);
		assertEquals(carlJohnson, arr[0]);
		assertEquals(aliceJones, arr[1]);
		assertEquals(bobSmith, arr[2]);
		assertEquals(johnSmith, arr[3]);
		assertEquals(johnSmith2, arr[4]);
	}
	
	@Test
	public void testReverseSort() {
		Arrays.sort(arr, new ReverseEmployeeComparator());
		assertEquals(carlJohnson, arr[4]);
		assertEquals(aliceJones, arr[3]);
		assertEquals(bobSmith, arr[2]);
		assertEquals(johnSmith, arr[1]);
		assertEquals(johnSmith2, arr[0]);
	}
	
	@Test
	public void testReverseBubbleSort() {
		BubbleSort.bubbleSort(arr, new ReverseEmployeeComparator());
		assertEquals(carlJohnson, arr[4]);
		assertEquals(aliceJones, arr[3]);
		assertEquals(bobSmith, arr[2]);
		assertEquals(johnSmith, arr[1]);
		assertEquals(johnSmith2, arr[0]);
	}
}
