package edu.ycp.cs201.genericmethods;

public class Employee implements Comparable<Employee> {
	private String lastName;
	private String firstName;
	private int id;
	
	public Employee(String lastName, String firstName, int id) {
		this.lastName = lastName;
		this.firstName = firstName;
		this.id = id;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public int getId() {
		return id;
	}

	@Override
	public int compareTo(Employee o) {
		int cmp;
		
		// compare last names
		cmp = this.lastName.compareTo(o.lastName);
		if (cmp != 0) {
			return cmp;
		}
		
		// compare first names
		cmp = this.firstName.compareTo(o.firstName);
		if (cmp != 0) {
			return cmp;
		}
		
		// compare id numbers
		if (this.id < o.id) {
			return -1;
		} else if (this.id > o.id) {
			return 1;
		} else {
			return 0;
		}
	}
}
