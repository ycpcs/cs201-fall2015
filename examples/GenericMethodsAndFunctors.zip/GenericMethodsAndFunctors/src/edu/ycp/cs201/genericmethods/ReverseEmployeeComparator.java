package edu.ycp.cs201.genericmethods;

import java.util.Comparator;

public class ReverseEmployeeComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.compareTo(o2) * -1;
	}

}
