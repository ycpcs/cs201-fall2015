package edu.ycp.cs201.arraylists;

import java.util.ArrayList;

public class ArrayLists {
	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<String>();
		
		names.add("Alice");
		names.add("Bob");
		names.add("Carl");
		
		System.out.println(names.get(0));
		System.out.println("there are " + names.size() + " elements");
		
		for (int i = 0; i < names.size(); i++) {
			System.out.println("Element " + i + ": " + names.get(i));
		}
		
		// Better!
		for (String name : names) {
			System.out.println(name);
		}
		
		// If you want to remove selected elements from the array list
		// E.g., remove all names starting with 'B'
		ArrayList<String> toRemove = new ArrayList<String>();
		for (String name : names) {
			if (name.startsWith("B")) {
				toRemove.add(name);
			}
		}
		names.removeAll(toRemove);
		
		System.out.println("After removing names starting with B:");
		for (String name : names) {
			System.out.println(name);
		}
	}
}
