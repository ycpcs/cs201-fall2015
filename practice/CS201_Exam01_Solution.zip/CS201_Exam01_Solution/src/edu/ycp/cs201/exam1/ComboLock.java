package edu.ycp.cs201.exam1;

public class ComboLock {
	private int[] combo;
	private int[] attempt;
	private int numSpins;

	public ComboLock(int a, int b, int c) {
		combo = new int[3];
		combo[0] = a;
		combo[1] = b;
		combo[2] = c;
		attempt = new int[3];
		numSpins = 0;
	}

	public void spin(int n) {
		if (numSpins < 3) {
			attempt[numSpins] = n;
			numSpins++;
		}
	}

	public boolean isUnlocked() {
		if (numSpins == 3 &&
				attempt[0] == combo[0] &&
				attempt[1] == combo[1] &&
				attempt[2] == combo[2]) {
			return true;
		} else {
			return false;
		}
	}

	public void lock() {
		numSpins = 0;
	}
}
