package edu.ycp.cs201.exam1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ComboLockTest {
	private ComboLock lock;

	@Before
	public void setUp() {
		lock = new ComboLock(21, 8, 14);
	}

	@Test
	public void testInvalidCombo() {
		lock.spin(21);
		lock.spin(9);
		lock.spin(14);
		assertFalse(lock.isUnlocked());
	}

	@Test
	public void testValidCombo() {
		lock.spin(21);
		lock.spin(8);
		lock.spin(14);
		assertTrue(lock.isUnlocked());
	}
	
	@Test
	public void testLock() throws Exception {
		// Unlock the lock
		lock.spin(21);
		lock.spin(8);
		lock.spin(14);
		assertTrue(lock.isUnlocked());
		
		// Lock it, check that it is locked again
		lock.lock();
		assertFalse(lock.isUnlocked());
		
		// Unlock it again
		lock.spin(21);
		lock.spin(8);
		lock.spin(14);
		assertTrue(lock.isUnlocked());
	}
}
