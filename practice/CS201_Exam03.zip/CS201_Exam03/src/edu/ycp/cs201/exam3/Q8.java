package edu.ycp.cs201.exam3;

public class Q8 {
	// Return the product of a and b.
	// You can assume that both a and b are non-negative.
	// IMPORTANT: Your implementation must be recursive.
	public static int multiply(int a, int b) {
		// Remove the following statement
		throw new UnsupportedOperationException("TODO - implement");
	}
}
