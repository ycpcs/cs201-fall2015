package edu.ycp.cs201.exam3;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q8Test {
	@Test
	public void testEasy() {
		assertEquals(8, Q8.multiply(2,  4));
		assertEquals(8, Q8.multiply(4,  2));
	}
	
	@Test
	public void testEasy2() {
		assertEquals(39, Q8.multiply(3, 13));
		assertEquals(39, Q8.multiply(13, 3));
	}
	
	@Test
	public void testAIsZero() {
		assertEquals(0, Q8.multiply(0, 42));
		assertEquals(0, Q8.multiply(0, 0));
		assertEquals(0, Q8.multiply(0, 1));
	}
	
	@Test
	public void testBIsZero() {
		assertEquals(0, Q8.multiply(42, 0));
		assertEquals(0, Q8.multiply(0, 0));
		assertEquals(0, Q8.multiply(1, 0));
	}
	
	@Test
	public void testAIsOne() {
		assertEquals(42, Q8.multiply(1, 42));
		assertEquals(0, Q8.multiply(1, 0));
		assertEquals(1, Q8.multiply(1, 1));
	}
	
	@Test
	public void testBIsOne() {
		assertEquals(42, Q8.multiply(42, 1));
		assertEquals(0, Q8.multiply(0, 1));
		assertEquals(1, Q8.multiply(1, 1));
	}
}
