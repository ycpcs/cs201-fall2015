package edu.ycp.cs201.finalexam;

import java.util.ArrayList;
import java.util.List;

public class Q12 {
	public static<E> void collate(List<E> list) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
