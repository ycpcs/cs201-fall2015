package edu.ycp.cs201.exam2;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Q9 {
	public static<E> boolean isAscending(List<E> list, Comparator<E> comp) {
		throw new UnsupportedOperationException("TODO: implement");
	}

	// This method is for the bonus question
	public static<E> boolean isDescending(List<E> list, Comparator<E> comp) {
		throw new UnsupportedOperationException("TODO: implement");
	}
}
