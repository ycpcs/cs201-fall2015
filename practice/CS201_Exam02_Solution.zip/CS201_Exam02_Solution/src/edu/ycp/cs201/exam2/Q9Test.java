package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q9Test {
	// Compare strings using the "natural" order provided by the String
	// class's compareTo method, which compares strings by lexicographical
	// order.
	public static class NaturalStringComparator implements Comparator<String> {
		@Override
		public int compare(String o1, String o2) {
			return o1.compareTo(o2);
		}
	}
	
	// Compare integers using the "natural" order provided by the Integer
	// class's compareTo method, which compares integers using normal
	// integer comparison.
	public static class NaturalIntegerComparator implements Comparator<Integer> {
		@Override
		public int compare(Integer o1, Integer o2) {
			return o1.compareTo(o2);
		}
	}
	
	private List<String> ascStringList;
	private List<String> nonAscStringList1;
	private List<String> nonAscStringList2;
	private List<Integer> ascIntegerList;
	private List<Integer> nonAscIntegerList1;
	private List<Integer> nonAscIntegerList2;
	private List<Integer> nonAscIntegerList3;
	
	private List<String> listWithOneString;
	private List<Integer> listWithOneInteger;
	
	@Before
	public void setUp() {
		ascStringList = Arrays.asList(
				"apples", "bananas", "cantaloupes", "dates", "figs", "grapes",
				"lemons", "nectarines", "quinces", "strawberries", "watermelons");
		nonAscStringList1 = Arrays.asList("alice", "carl", "bob");
		nonAscStringList2 = Arrays.asList("alice", "bob", "carl", "card", "delores");
		
		ascIntegerList = Arrays.asList(8, 17, 29, 38, 40, 41, 49, 66, 81, 98);
		nonAscIntegerList1 = Arrays.asList(8, 17, 29, 40, 38, 41, 49, 66, 81, 98);
		nonAscIntegerList2 = Arrays.asList(8, 17, 29, 38, 40, 41, 49, 66, 98, 81);
		nonAscIntegerList3 = Arrays.asList(8, 8, 29, 38, 40, 41, 49, 66, 81, 98);
		
		// Any list with a single element is trivially considered to be in ascending order
		listWithOneString = Arrays.asList("yeah");
		listWithOneInteger = Arrays.asList(42);
	}
	
	@Test
	public void testIsAscending() throws Exception {
		assertTrue(Q9.isAscending(ascStringList, new NaturalStringComparator()));
		assertTrue(Q9.isAscending(ascIntegerList, new NaturalIntegerComparator()));
		assertTrue(Q9.isAscending(listWithOneString, new NaturalStringComparator()));
		assertTrue(Q9.isAscending(listWithOneInteger, new NaturalIntegerComparator()));
	}
	
	@Test
	public void testIsNotAscending() throws Exception {
		assertFalse(Q9.isAscending(nonAscStringList1, new NaturalStringComparator()));
		assertFalse(Q9.isAscending(nonAscStringList2, new NaturalStringComparator()));
		assertFalse(Q9.isAscending(nonAscIntegerList1, new NaturalIntegerComparator()));
		assertFalse(Q9.isAscending(nonAscIntegerList2, new NaturalIntegerComparator()));
		assertFalse(Q9.isAscending(nonAscIntegerList3, new NaturalIntegerComparator()));
	}
}
