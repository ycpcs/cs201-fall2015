package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q9BonusTest {
	private List<Integer> descIntegerList;
	private List<Integer> nonDescIntegerList1;
	private List<Integer> nonDescIntegerList2;
	private List<Integer> nonDescIntegerList3;
	private List<Integer> nonDescIntegerList4;
	
	@Before
	public void setUp() {
		descIntegerList = Arrays.asList(123, 99, 98, 45, 31, 8, 4);
		nonDescIntegerList1 = Arrays.asList(123, 99, 98, 31, 45, 8, 4);
		nonDescIntegerList2 = Arrays.asList(99, 123, 98, 45, 31, 8, 4);
		nonDescIntegerList3 = Arrays.asList(123, 99, 98, 45, 31, 4, 8);
		nonDescIntegerList4 = Arrays.asList(123, 99, 98, 45, 31, 31, 8, 4);
	}
	
	@Test
	public void testIsDescending() {
		assertTrue(Q9.isDescending(descIntegerList, new Q9Test.NaturalIntegerComparator()));
	}
	
	@Test
	public void testIsNotDescending() throws Exception {
		assertFalse(Q9.isDescending(nonDescIntegerList1, new Q9Test.NaturalIntegerComparator()));
		assertFalse(Q9.isDescending(nonDescIntegerList2, new Q9Test.NaturalIntegerComparator()));
		assertFalse(Q9.isDescending(nonDescIntegerList3, new Q9Test.NaturalIntegerComparator()));
		assertFalse(Q9.isDescending(nonDescIntegerList4, new Q9Test.NaturalIntegerComparator()));
	}
}
