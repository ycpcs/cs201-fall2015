package edu.ycp.cs201.exam3;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Q9 {
	public static<E extends Comparable<E>> int countUnique(Collection<E> coll) {
		TreeSet<E> set = new TreeSet<E>();
		set.addAll(coll);
		return set.size();
	}
}
