package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import org.junit.Before;
import org.junit.Test;

public class Q11Test {
	private static class NaturalComparator<E extends Comparable<E>> implements Comparator<E> {
		@Override
		public int compare(E o1, E o2) {
			return o1.compareTo(o2);
		}
	}
	
	private static class ReverseComparator<E extends Comparable<E>> implements Comparator<E> {
		@Override
		public int compare(E o1, E o2) {
			return o2.compareTo(o1);
		}
	}
	
	private ArrayList<String> list1;
	private ArrayList<Integer> list2;
	
	@Before
	public void setUp() {
		list1 = new ArrayList<String>(
				Arrays.asList("X", "Q", "Z", "P", "I", "F", "T", "B", "J", "D"));
		list2 = new ArrayList<Integer>(
				Arrays.asList(80, 49, 58, 7, 66, 72, 4, 82, 66, 28, 15, 83, 12, 72, 15));
	}
	
	@Test
	public void testString1() throws Exception {
		assertEquals("Z", Q11.findNthLargest(list1, 1, new NaturalComparator<String>()));
	}
	
	@Test
	public void testString2() throws Exception {
		assertEquals("X", Q11.findNthLargest(list1, 2, new NaturalComparator<String>()));
	}
	
	@Test
	public void testString3() throws Exception {
		assertEquals("T", Q11.findNthLargest(list1, 3, new NaturalComparator<String>()));
	}
	
	@Test
	public void testInt1() throws Exception {
		assertEquals((Integer)83, Q11.findNthLargest(list2, 1, new NaturalComparator<Integer>()));
	}
	
	@Test
	public void testInt2() throws Exception {
		assertEquals((Integer)82, Q11.findNthLargest(list2, 2, new NaturalComparator<Integer>()));
	}
	
	@Test
	public void testInt3() throws Exception {
		assertEquals((Integer)80, Q11.findNthLargest(list2, 3, new NaturalComparator<Integer>()));
	}
	
	@Test
	public void testReverseString1() throws Exception {
		assertEquals("B", Q11.findNthLargest(list1, 1, new ReverseComparator<String>()));
	}
	
	@Test
	public void testReverseString2() throws Exception {
		assertEquals("D", Q11.findNthLargest(list1, 2, new ReverseComparator<String>()));
	}
	
	@Test
	public void testReverseInt1() throws Exception {
		assertEquals((Integer)4, Q11.findNthLargest(list2, 1, new ReverseComparator<Integer>()));
	}
	
	@Test
	public void testReverseInt2() throws Exception {
		assertEquals((Integer)7, Q11.findNthLargest(list2, 2, new ReverseComparator<Integer>()));
	}
}
