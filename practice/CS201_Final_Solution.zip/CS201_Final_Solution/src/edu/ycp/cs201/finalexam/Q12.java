package edu.ycp.cs201.finalexam;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Q12 {
	public static<E> void collate(List<E> list) {
		ArrayList<E> evens = new ArrayList<E>();
		ArrayList<E> odds = new ArrayList<E>();
		Iterator<E> i = list.iterator();
		while (i.hasNext()) {
			evens.add(i.next());
			if (i.hasNext()) {
				odds.add(i.next());
			}
		}
		list.clear();
		list.addAll(evens);
		list.addAll(odds);
	}
}
