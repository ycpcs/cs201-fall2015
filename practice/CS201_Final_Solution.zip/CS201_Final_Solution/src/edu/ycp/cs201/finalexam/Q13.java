package edu.ycp.cs201.finalexam;

public class Q13 {
	public static String insertCommas(String s) {
		if (s.length() < 2) {
			return s;
		} else {
			return s.charAt(0) + "," + insertCommas(s.substring(1));
		}
	}
}
